import requests

def recalculate_leaderboard():
    url = "http://meta.pylex.xyz:9027/api/recalculate_leaderboard"
    headers = {
        "Authorization": "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJmcmVzaCI6ZmFsc2UsImlhdCI6MTczOTM4OTcwMSwianRpIjoiYjkzZWI2YzEtNWFmZS00Mzk1LTg1ODktODU1ZjA1MTkzZGI1IiwidHlwZSI6ImFjY2VzcyIsInN1YiI6eyJ1c2VyX2lkIjoiMDAwMSIsImNsYXNzMTAiOnRydWV9LCJuYmYiOjE3MzkzODk3MDF9.T176rCEaNx5gUlw12JpBuWHQidieQcPZwacgyFH7sZg",
        "Content-Type": "application/json"
    }
    data = {}
    
    response = requests.post(url, headers=headers, json=data)
    return response.json()


print(recalculate_leaderboard())